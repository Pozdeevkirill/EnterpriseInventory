/* Elements */
let cabinetTable = document.querySelector("#cabinet_table");
let itemTable = document.querySelector("#item_table");

/* Modal window elements */
let modalWindow = document.querySelector("#black_background");
let modalTitle = document.querySelector("#modal_title");
let modalContent = document.querySelector("#modal_content");
let closeModalWindowBtn = document.querySelector("#close_btn");

/* Buttons */
let allCabinetsBtn = document.querySelector("#allCabinets");
let addCabinetBtn = document.querySelector("#addCabinet"); 

let allItemsBtn = document.querySelector("#allItems");
let addItemBtn = document.querySelector("#addItem"); 

let cabinets = [];
let items = [];

let api = "https://localhost:7169/api/";
Start();
async function Start() {
    UpdateCabinetsTable(await GetAllCabinets());
    UpdateItemTable(await GetAllItem());
}

function ClearTable(table) {
    table.innerHTML = "";
}

//#region Buttons click
allCabinetsBtn.addEventListener('click', async () => {
    ClearTable(cabinetTable);
    UpdateCabinetsTable(await GetAllCabinets());
});

allItemsBtn.addEventListener('click', async () => {
    UpdateItemTable(await GetAllItem());
});
closeModalWindowBtn.addEventListener('click', CloseWindow);

async function GetItemByCabinet(id) {
    let cabinet = await GetCabinetById(id);
    console.log(cabinet);
    UpdateItemTable(cabinet.items);
}

addCabinet.addEventListener('click', ModalCreateCabinetBtn);
addItemBtn.addEventListener('click', ModalCreateItemBtn);

//#endregion
//#region Modal window

//#region Modal window Item
async function ModalCreateItemBtn(){
    modalTitle.textContent = "Создадние предмета";
    modalContent.innerHTML = "";
    modalWindow.style.display = "block";

    modalContent.innerHTML = `
            <div class="row">
                <span class="row_title">Артикул:</span>
                <input type="number" class="row_input" id="article">
            </div>
            <div class="row">
                <span class="row_title">Название:</span>
                <input type="text" class="row_input" id="item_name">
            </div>
            <div class="row">
                <span class="row_title">Название кабинета:</span>
                <input type="text" class="row_input" id="cabinet_name">
            </div>
            <div class="modal_buttons">
                <div class="btn edit_btn" onclick="SaveCreatedItem()">Создать</div>
                <div class="btn view_btn" id="cancel_btn" onclick="CloseWindow()">Отмена</div>
            </div>
    `;
}

async function ModalEditItemBtn(id){
    modalTitle.textContent = "Редактирование предмета";
    modalContent.innerHTML = "";
    modalWindow.style.display = "block";
    let item = await GetItemById(id);
    modalContent.innerHTML = `
        <div class="row">
            <span class="row_title">Артикул:</span>
            <input type="number" class="row_input" id="article" value="${item.article}">
        </div>
        <div class="row">
            <span class="row_title">Название:</span>
            <input type="text" class="row_input" id="item_name" value="${item.name}">
        </div>
        <div class="row">
            <span class="row_title">Название кабинета:</span>
            <input type="text" class="row_input" id="cabinet_name" value="${item.cabinetName}">
        </div>
        <div class="modal_buttons">
            <div class="btn edit_btn" onclick="SaveEditItem(${id})">Сохранить</div>
            <div class="btn view_btn" id="cancel_btn" onclick="CloseWindow()">Отмена</div>
        </div>
    `;
}

async function SaveEditItem(_id){
    let _article = modalContent.querySelector("#article");
    let _name = modalContent.querySelector("#item_name");
    let _cabinetName = modalContent.querySelector("#cabinet_name"); 
    let item = {
        id: _id,
        article: _article.value,
        name: _name.value,
        cabinetName: _cabinetName.value 
    };

    await EditItem(item);

    CloseWindow();
    UpdateItemTable(await GetAllItem());
}

async function SaveCreatedItem(){
    let _article = modalContent.querySelector("#article");
    let _name = modalContent.querySelector("#item_name");
    let _cabinetName = modalContent.querySelector("#cabinet_name");
    let item = {
        name: _name.value,
        article: _article.value,
        cabinetName: _cabinetName.value
    }


    await CreateItem(item);
    CloseWindow();
    UpdateItemTable(await GetAllItem());
}
//#endregion

//#region Modal window Cabinet
async function ModalCreateCabinetBtn() {
    modalTitle.textContent = "Создадние кабинета";
    modalContent.innerHTML = "";
    modalWindow.style.display = "block";

    modalContent.innerHTML = `
    <div class="row">
        <span class="row_title">Название кабинета:</span>
        <input type="text" class="row_input" id="name_cabinet">
    </div>
    <div class="row">
        <span class="row_title">Владелец кабинета:</span>
        <input type="text" class="row_input" id="owner_cabinet">
    </div>
    <div class="modal_buttons">
        <div class="btn edit_btn" onclick="SaveCreateCabinet()">Создать</div>
        <div class="btn view_btn" id="cancel_btn" onclick="CloseWindow()">Отмена</div>
    </div>
    `;

}

async function ModalCabinetEditBtn(id){
    modalTitle.textContent = "Редактирование кабинета";
    modalContent.innerHTML = "";
    modalWindow.style.display = "block";
    let cabinet = await GetCabinetById(id);
    modalContent.innerHTML = `
                <div class="row">
                    <span class="row_title">Название кабинета:</span>
                    <input type="text" class="row_input" value="${cabinet.name}" id="name_cabinet">
                </div>
                <div class="row">
                    <span class="row_title">Владелец кабинета:</span>
                    <input type="text" class="row_input" value="${cabinet.owner}" id="owner_cabinet">
                </div>
                <div class="modal_buttons">
                    <div class="btn edit_btn" onclick="SaveEditCabinet(${id})">Сохранить</div>
                    <div class="btn view_btn" id="cancel_btn" onclick="CloseWindow()">Отмена</div>
                </div>
    `;
}

async function SaveEditCabinet(_id){
    let _name = modalContent.querySelector("#name_cabinet");
    let _owner = modalContent.querySelector("#owner_cabinet");

    let cabinet = {
        id:_id,
        name:_name.value,
        owner:_owner.value,
        items: []
    }
    console.log(cabinet);

    await EditCabinet(cabinet);
    CloseWindow();
    UpdateCabinetsTable(await GetAllCabinets());
}

async function SaveCreateCabinet() {
    let _name = modalContent.querySelector("#name_cabinet");
    let _owner = modalContent.querySelector("#owner_cabinet");

    let cabinet = {
        name:_name.value,
        owner:_owner.value,
    }

    await CreateCabinet(cabinet);
    CloseWindow();
    UpdateCabinetsTable(await GetAllCabinets());
}
//#endregion

function CloseWindow(){
    modalTitle.textContent = "ModalTitle";
    modalContent.innerHTML = "";
    modalWindow.style.display = "none";
}
//#endregion



//#region  Update Interface Methods
async function UpdateCabinetsTable(data) {
    
    cabinetTable.innerHTML = `
    <tr>
        <th class="id">Id</th>
        <th>Название</th>
        <th>Владелец</th>
        <th colspan="3"></th>
    </tr>
    `;
    for(let i = 0; i < data.length; i++){
        let tr = document.createElement('tr');
        tr.innerHTML += `
            <td class="id" id="cabinet_${data[i].id}">${i+1}</td>
            <td>${data[i].name}</td>
            <td>${data[i].owner}</td>
            <td>
                <div class="btn view_btn" onclick="GetItemByCabinet(${data[i].id})">Подробнее</div>
            </td>
            <td>
                <div class="btn edit_btn" onclick="ModalCabinetEditBtn(${data[i].id})">Редактировать</div>
            </td>
            <td>
                <div class="btn delete_btn" onclick="DeleteCabinet(${data[i].id})">Удалить</div>
            </td>
        
        `;
        cabinetTable.append(tr);
        cabinets.push(tr);
    }
}
async function UpdateItemTable(data){
    itemTable.innerHTML =`
        <tr>
            <th class="id">Id</th>
            <th>Артикул</th>
            <th>Название</th>
            <th>Кабинет</th>
            <th colspan="2"></th>
        </tr>
    `;

    for(let i = 0; i < data.length; i++){
        let tr = document.createElement(`tr`);
        tr.innerHTML = `
        <td class="id" id="item_${data[i].id}">${i + 1}</td>
        <td>${data[i].article}</td>
        <td>${data[i].name}</td>
        <td>${data[i].cabinetName}</td>
        <td>
            <div class="btn edit_btn" onclick="ModalEditItemBtn(${data[i].id})">Редактировать</div>
        </td>
        <td>
            <div class="btn delete_btn" onclick="DeleteItem(${data[i].id})">Удалить</div>
        </td>
        
        `;
        itemTable.append(tr);
        items.push(tr);
}}
//#endregion

//#region Methods for communication with api

//#region Items
async function GetAllItem(){
    let response = await fetch(api + "item", {
        method: "GET",
        mode: "cors",
        withCredentials: true,
        headers:{
            "Access-Control-Allow-Origin":"*"
        }
    });
    let result = await response.json();
    return result.data;
}

async function DeleteItem(id){
    //Удаление из БД
    await fetch(api + `item/remove?id=${id}`,{
        method: "DELETE",
        headers: {
            'Content-Type': 'application/json',
        },
        withCredentials: true,
    })
    .then(resp => {
        resp.headers.forEach(function(val, key) { console.log(key + ' -> ' + val); });
        console.log(resp);
        return resp.json()
    })
    .then(json => {
        console.log(json);
    });

    //Удаление из таблицы
    let item = document.querySelector(`#item_${id}`).textContent;
    items[item - 1].innerHTML = "";
    items.splice(item-1,1);
}

async function CreateItem(item){
    let response = await fetch(api + `item/add`, {
        method: "POST",
        mode: "cors",
        withCredentials: true,
        headers:{
            "Access-Control-Allow-Origin":"*",
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(item)
    });
}

async function GetItemById(id){
    let response = await fetch(api + `item/${id}`, {
        method: "GET",
        mode: "cors",
        withCredentials: true,
        headers:{
            "Access-Control-Allow-Origin":"*"
        }
    });
    let result = await response.json();
    console.log(result)
    return result.data;
}

async function EditItem(item){
    let response = await fetch(api + `item/update`, {
        method: "POST",
        mode: "cors",
        withCredentials: true,
        headers:{
            "Access-Control-Allow-Origin":"*",
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(item)
    });
}
//#endregion

//#region Cabinets api methods

async function GetAllCabinets() {
    let response = await fetch(api + "cabinet", {
        method: "GET",
        mode: "cors",
        withCredentials: true,
        headers:{
            "Access-Control-Allow-Origin":"*"
        }
    });
    let result = await response.json();
    
    return result.data;
}

async function DeleteCabinet(id){

    //Удаление из БД
    await fetch(api + `cabinet/remove?id=${id}`,{
        method: "DELETE",
        headers: {
            'Content-Type': 'application/json',
        },
        withCredentials: true,
    })
    .then(resp => {
        resp.headers.forEach(function(val, key) { console.log(key + ' -> ' + val); });
        console.log(resp);
        return resp.json()
    })
    .then(json => {
        console.log(json);
    });

    //Удаление из таблицы
    let cabinet = document.querySelector(`#cabinet_${id}`).textContent;
    cabinets[cabinet-1].innerHTML = "";
    cabinets.splice(cabinet,1);

}

async function GetCabinetById(id){
    let response = await fetch(api + `cabinet/${id}`, {
        method: "GET",
        mode: "cors",
        withCredentials: true,
        headers:{
            "Access-Control-Allow-Origin":"*"
        }
    });
    let result = await response.json();
    
    return result.data;
}

async function EditCabinet(cabinet){
    let response = await fetch(api + `cabinet/update`, {
        method: "POST",
        mode: "cors",
        withCredentials: true,
        headers:{
            "Access-Control-Allow-Origin":"*",
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(cabinet)
    });
}

async function CreateCabinet(cabinet){
    let response = await fetch(api + `cabinet/add`, {
        method: "POST",
        mode: "cors",
        withCredentials: true,
        headers:{
            "Access-Control-Allow-Origin":"*",
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(cabinet)
    });

    
}
//#endregion
//#endregion